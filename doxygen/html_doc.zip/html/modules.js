var modules =
[
    [ "Main menu", "group__main__menu.html", "group__main__menu" ],
    [ "Calibration mode", "group__factory_calibr.html", "group__factory_calibr" ],
    [ "Etalon's data write", "group__pre_amp_calibr.html", "group__pre_amp_calibr" ]
];