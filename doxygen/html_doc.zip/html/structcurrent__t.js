var structcurrent__t =
[
    [ "curr1", "structcurrent__t.html#a67184c6cc4a6cc7d301880214965518b", null ],
    [ "curr2", "structcurrent__t.html#aa9880547f852fd6b213265f267da44c8", null ]
];