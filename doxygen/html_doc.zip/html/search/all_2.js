var searchData=
[
  ['coeffs',['coeffs',['../analizer_8h.html#a515bd80a2008b8ce4477be6f8f4fa692',1,'analizer.h']]],
  ['cur4allled',['cur4AllLed',['../analizer_8h.html#a6bccd06c6f4cd5703f2aad7e7bf19d8a',1,'analizer.h']]],
  ['curr1',['curr1',['../structcurrent__t.html#a67184c6cc4a6cc7d301880214965518b',1,'current_t']]],
  ['curr2',['curr2',['../structcurrent__t.html#aa9880547f852fd6b213265f267da44c8',1,'current_t']]],
  ['current_5ft',['current_t',['../structcurrent__t.html',1,'']]],
  ['calibration_20mode',['Calibration mode',['../group__factory_calibr.html',1,'']]]
];
