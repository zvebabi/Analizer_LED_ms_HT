var searchData=
[
  ['onetimes',['oneTimes',['../analizer_8h.html#ab7bf7e4c38fa1ebbfe16fe17b09be01f',1,'analizer.h']]]
];
