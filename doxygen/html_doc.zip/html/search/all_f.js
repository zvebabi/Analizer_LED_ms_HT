var searchData=
[
  ['serialclean',['SerialClean',['../analizer_8cpp.html#a5997158c293a908f361bed8d45f3fbf3',1,'SerialClean():&#160;analizer.cpp'],['../analizer_8h.html#a5997158c293a908f361bed8d45f3fbf3',1,'SerialClean():&#160;analizer.cpp']]],
  ['setc_5fr',['setC_R',['../analizer_8cpp.html#a9d89d31f162632847065a02672f9b7e0',1,'setC_R(float val):&#160;analizer.cpp'],['../analizer_8h.html#a9d89d31f162632847065a02672f9b7e0',1,'setC_R(float val):&#160;analizer.cpp']]],
  ['setcurrent',['setCurrent',['../analizer_8cpp.html#a8563e0a3c9ecbe8ddfbcd9830835f1e6',1,'setCurrent(uint8_t channelN, uint16_t curValue):&#160;analizer.cpp'],['../analizer_8h.html#aae376c2e319f44189128b3b2889b4030',1,'setCurrent(uint8_t channelN, uint16_t currValue):&#160;analizer.cpp']]],
  ['setpreamp',['setPreAmp',['../analizer_8cpp.html#aa856f479273cf2e67fc85279c8b53ce5',1,'setPreAmp(float RWB1, float RWB2):&#160;analizer.cpp'],['../analizer_8h.html#aa856f479273cf2e67fc85279c8b53ce5',1,'setPreAmp(float RWB1, float RWB2):&#160;analizer.cpp']]],
  ['setpulsewidth',['setPulseWidth',['../analizer_8cpp.html#a7028e4cbf9b5159558440a1fd4228149',1,'setPulseWidth(uint16_t width):&#160;analizer.cpp'],['../analizer_8h.html#a7028e4cbf9b5159558440a1fd4228149',1,'setPulseWidth(uint16_t width):&#160;analizer.cpp']]],
  ['setup',['setup',['../analizer_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;analizer.cpp'],['../analizer_8h.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;analizer.cpp']]],
  ['sh_5fport',['SH_PORT',['../analizer_8h.html#a22e32198639ff7666964ceb2c7663ce2',1,'analizer.h']]],
  ['sh_5freset',['SH_RESET',['../analizer_8h.html#ab740c8813d932dfe825663ad9ade65ac',1,'analizer.h']]],
  ['sh_5fset',['SH_SET',['../analizer_8h.html#a2d989d6cda290418d17bb6e0f2693b3c',1,'analizer.h']]],
  ['shiftregisterdelay',['ShiftRegisterDelay',['../analizer_8h.html#a7eba70092c80595372a62a2129c15d38',1,'analizer.h']]],
  ['shiftregisterfirst',['shiftRegisterFirst',['../analizer_8cpp.html#a630003ae387b30a0811665c6887fba7d',1,'shiftRegisterFirst():&#160;analizer.cpp'],['../analizer_8h.html#a630003ae387b30a0811665c6887fba7d',1,'shiftRegisterFirst():&#160;analizer.cpp']]],
  ['shiftregisternext',['shiftRegisterNext',['../analizer_8cpp.html#a97373a5239e1af8b6e6be8d4b63663e4',1,'shiftRegisterNext():&#160;analizer.cpp'],['../analizer_8h.html#a97373a5239e1af8b6e6be8d4b63663e4',1,'shiftRegisterNext():&#160;analizer.cpp']]],
  ['shiftregisterreset',['shiftRegisterReset',['../analizer_8cpp.html#a8d1f3576892bbeffb58ea18abfc2b823',1,'shiftRegisterReset():&#160;analizer.cpp'],['../analizer_8h.html#a8d1f3576892bbeffb58ea18abfc2b823',1,'shiftRegisterReset():&#160;analizer.cpp']]],
  ['spi_2ed',['SPI.d',['../_s_p_i_8d.html',1,'']]],
  ['sr_5fclk',['SR_CLK',['../analizer_8h.html#a86d5a90c888ff7597811ad9356383dd9',1,'analizer.h']]],
  ['sr_5fclr',['SR_CLR',['../analizer_8h.html#a9d3e7db6665a7ef3578f39a55b80caff',1,'analizer.h']]],
  ['sr_5fdata',['SR_DATA',['../analizer_8h.html#acb10407e3214cbd4dbbb30d143d2ff64',1,'analizer.h']]],
  ['sr_5fenable',['SR_ENABLE',['../analizer_8h.html#afa636b6fa889108da6792530f7c7e604',1,'analizer.h']]],
  ['ss_5fadc',['SS_ADC',['../analizer_8h.html#a578b28f704eca688ec84459052e700c1',1,'analizer.h']]],
  ['ss_5fdac',['SS_DAC',['../analizer_8h.html#a6acb416abfa9b672f29efbce6b4f514d',1,'analizer.h']]],
  ['ss_5fpreamp',['SS_PREAMP',['../analizer_8h.html#a7e138e04db53cabc3b98326ba1703972',1,'analizer.h']]]
];
