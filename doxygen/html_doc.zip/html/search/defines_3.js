var searchData=
[
  ['max_5fcurrent',['MAX_CURRENT',['../analizer_8h.html#a2989837a37d6d63b59c6dd541b785435',1,'analizer.h']]],
  ['max_5fpulse_5fwidth',['MAX_PULSE_WIDTH',['../analizer_8h.html#a57a10261e6511f97317cee9076692315',1,'analizer.h']]]
];
