var searchData=
[
  ['dac_5fport',['DAC_PORT',['../analizer_8h.html#afbdc123b0b82a37ee0e8272c6e39e66c',1,'analizer.h']]],
  ['dacdelay',['DACDelay',['../analizer_8h.html#a2553b1fa6f7f5606de68a2df573221e2',1,'analizer.h']]],
  ['disableled',['disableLED',['../analizer_8cpp.html#a9383278dce0daeb3cec5424679c5b815',1,'disableLED():&#160;analizer.cpp'],['../analizer_8h.html#a9383278dce0daeb3cec5424679c5b815',1,'disableLED():&#160;analizer.cpp']]],
  ['discharge_5fdelay',['DISCHARGE_DELAY',['../analizer_8h.html#a85eee24026283aa727d1cb401b1e16b5',1,'analizer.h']]],
  ['dischargesamplehold',['dischargeSampleHold',['../analizer_8cpp.html#a5bb74041e7d0fa1c5edbd3dce87f5048',1,'dischargeSampleHold():&#160;analizer.cpp'],['../analizer_8h.html#a5bb74041e7d0fa1c5edbd3dce87f5048',1,'dischargeSampleHold():&#160;analizer.cpp']]],
  ['domeasurements',['doMeasurements',['../analizer_8cpp.html#a27a63ca1875269459f73d3d42c96e69d',1,'doMeasurements(uint8_t numOfEtalon, bool calcNorm):&#160;analizer.cpp'],['../analizer_8h.html#ab68664ccade14fee45935208d6a19bfc',1,'doMeasurements(uint8_t numOfEtalon=0, bool calcNorm=false):&#160;analizer.cpp']]],
  ['domeasurementssh',['doMeasurementsSH',['../analizer_8cpp.html#a2a1145e3b9b91ff3a4285fdd1a7e12c7',1,'doMeasurementsSH(uint8_t numOfEtalon, bool calcNorm):&#160;analizer.cpp'],['../analizer_8h.html#a577f03741b4c820e66e0e76a984fa535',1,'doMeasurementsSH(uint8_t numOfEtalon=0, bool calcNorm=false):&#160;analizer.cpp']]],
  ['domeasurementssh_5favg',['doMeasurementsSH_Avg',['../analizer_8cpp.html#a9f60d86f45cad8d26b1af473247570b8',1,'doMeasurementsSH_Avg(bool calcNorm):&#160;analizer.cpp'],['../analizer_8h.html#aa3800b390098f0c30155a3b4c3629fc4',1,'doMeasurementsSH_Avg(bool calcNorm=false):&#160;analizer.cpp']]],
  ['doonepulse',['doOnePulse',['../analizer_8cpp.html#a367302e50a423db3a23f1be59a7fd4a2',1,'doOnePulse(uint16_t pulseWidth):&#160;analizer.cpp'],['../analizer_8h.html#a367302e50a423db3a23f1be59a7fd4a2',1,'doOnePulse(uint16_t pulseWidth):&#160;analizer.cpp']]]
];
