var searchData=
[
  ['preamp_5fport',['PREAMP_PORT',['../analizer_8h.html#a444e7e81c7325bd22f75bdec540b53e8',1,'analizer.h']]],
  ['pulse_5fdelay',['PULSE_DELAY',['../analizer_8h.html#a475c17e71b3911e78f6fa5c3062764bc',1,'analizer.h']]]
];
