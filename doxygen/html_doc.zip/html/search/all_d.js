var searchData=
[
  ['preamp_5fport',['PREAMP_PORT',['../analizer_8h.html#a444e7e81c7325bd22f75bdec540b53e8',1,'analizer.h']]],
  ['preampcalibr',['preAmpCalibr',['../group__pre_amp_calibr.html#ga083340ccd4aa08b8263fec04221bb0d5',1,'preAmpCalibr():&#160;analizer.cpp'],['../group__pre_amp_calibr.html#ga083340ccd4aa08b8263fec04221bb0d5',1,'preAmpCalibr():&#160;analizer.cpp']]],
  ['pulse_5fdelay',['PULSE_DELAY',['../analizer_8h.html#a475c17e71b3911e78f6fa5c3062764bc',1,'analizer.h']]],
  ['pulseend',['pulseEnd',['../analizer_8h.html#a81eef57f3f8c19b296ef1c12a59b66a8',1,'analizer.h']]]
];
