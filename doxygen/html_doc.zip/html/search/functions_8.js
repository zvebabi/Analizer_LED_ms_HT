var searchData=
[
  ['serialclean',['SerialClean',['../analizer_8cpp.html#a5997158c293a908f361bed8d45f3fbf3',1,'SerialClean():&#160;analizer.cpp'],['../analizer_8h.html#a5997158c293a908f361bed8d45f3fbf3',1,'SerialClean():&#160;analizer.cpp']]],
  ['setc_5fr',['setC_R',['../analizer_8cpp.html#a9d89d31f162632847065a02672f9b7e0',1,'setC_R(float val):&#160;analizer.cpp'],['../analizer_8h.html#a9d89d31f162632847065a02672f9b7e0',1,'setC_R(float val):&#160;analizer.cpp']]],
  ['setcurrent',['setCurrent',['../analizer_8cpp.html#a8563e0a3c9ecbe8ddfbcd9830835f1e6',1,'setCurrent(uint8_t channelN, uint16_t curValue):&#160;analizer.cpp'],['../analizer_8h.html#aae376c2e319f44189128b3b2889b4030',1,'setCurrent(uint8_t channelN, uint16_t currValue):&#160;analizer.cpp']]],
  ['setpreamp',['setPreAmp',['../analizer_8cpp.html#aa856f479273cf2e67fc85279c8b53ce5',1,'setPreAmp(float RWB1, float RWB2):&#160;analizer.cpp'],['../analizer_8h.html#aa856f479273cf2e67fc85279c8b53ce5',1,'setPreAmp(float RWB1, float RWB2):&#160;analizer.cpp']]],
  ['setpulsewidth',['setPulseWidth',['../analizer_8cpp.html#a7028e4cbf9b5159558440a1fd4228149',1,'setPulseWidth(uint16_t width):&#160;analizer.cpp'],['../analizer_8h.html#a7028e4cbf9b5159558440a1fd4228149',1,'setPulseWidth(uint16_t width):&#160;analizer.cpp']]],
  ['setup',['setup',['../analizer_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;analizer.cpp'],['../analizer_8h.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;analizer.cpp']]],
  ['shiftregisterfirst',['shiftRegisterFirst',['../analizer_8cpp.html#a630003ae387b30a0811665c6887fba7d',1,'shiftRegisterFirst():&#160;analizer.cpp'],['../analizer_8h.html#a630003ae387b30a0811665c6887fba7d',1,'shiftRegisterFirst():&#160;analizer.cpp']]],
  ['shiftregisternext',['shiftRegisterNext',['../analizer_8cpp.html#a97373a5239e1af8b6e6be8d4b63663e4',1,'shiftRegisterNext():&#160;analizer.cpp'],['../analizer_8h.html#a97373a5239e1af8b6e6be8d4b63663e4',1,'shiftRegisterNext():&#160;analizer.cpp']]],
  ['shiftregisterreset',['shiftRegisterReset',['../analizer_8cpp.html#a8d1f3576892bbeffb58ea18abfc2b823',1,'shiftRegisterReset():&#160;analizer.cpp'],['../analizer_8h.html#a8d1f3576892bbeffb58ea18abfc2b823',1,'shiftRegisterReset():&#160;analizer.cpp']]]
];
