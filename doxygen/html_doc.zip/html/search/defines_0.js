var searchData=
[
  ['adc_5fport',['ADC_PORT',['../analizer_8h.html#a1c6ce969ab3d12ac37f62c399a1e02c1',1,'analizer.h']]]
];
