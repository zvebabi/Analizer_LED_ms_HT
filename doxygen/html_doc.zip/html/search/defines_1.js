var searchData=
[
  ['dac_5fport',['DAC_PORT',['../analizer_8h.html#afbdc123b0b82a37ee0e8272c6e39e66c',1,'analizer.h']]],
  ['dacdelay',['DACDelay',['../analizer_8h.html#a2553b1fa6f7f5606de68a2df573221e2',1,'analizer.h']]],
  ['discharge_5fdelay',['DISCHARGE_DELAY',['../analizer_8h.html#a85eee24026283aa727d1cb401b1e16b5',1,'analizer.h']]]
];
