var searchData=
[
  ['reference_5fv',['REFERENCE_V',['../analizer_8h.html#afbca82ecf34ce7c95ce220c97c1645cf',1,'analizer.h']]]
];
