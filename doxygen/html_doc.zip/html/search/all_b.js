var searchData=
[
  ['num_5fof_5fetalon',['NUM_OF_ETALON',['../analizer_8h.html#a39d05713f9a15de04077b8bea7b13f44',1,'analizer.h']]],
  ['num_5fof_5fled',['NUM_OF_LED',['../analizer_8h.html#a2bdaf37b88fc3b0920fffa2b6166be22',1,'analizer.h']]]
];
