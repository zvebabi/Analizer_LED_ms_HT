var searchData=
[
  ['current_5ft',['current_t',['../structcurrent__t.html',1,'']]]
];
