var searchData=
[
  ['readadc',['readADC',['../analizer_8cpp.html#a4c374c3ab214a99569f29979606a8679',1,'readADC(float &amp;value):&#160;analizer.cpp'],['../analizer_8h.html#a4c374c3ab214a99569f29979606a8679',1,'readADC(float &amp;value):&#160;analizer.cpp']]],
  ['readadconetime',['readADCOneTime',['../analizer_8cpp.html#a7541e761cd601bddb339b3323d6dca81',1,'readADCOneTime(uint16_t &amp;value):&#160;analizer.cpp'],['../analizer_8h.html#a7541e761cd601bddb339b3323d6dca81',1,'readADCOneTime(uint16_t &amp;value):&#160;analizer.cpp']]],
  ['reference_5fv',['REFERENCE_V',['../analizer_8h.html#afbca82ecf34ce7c95ce220c97c1645cf',1,'analizer.h']]]
];
