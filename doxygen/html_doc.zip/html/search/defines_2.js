var searchData=
[
  ['gen1',['GEN1',['../analizer_8h.html#acc0381ac0fe7d05df767e24886574eda',1,'analizer.h']]],
  ['gen2',['GEN2',['../analizer_8h.html#a14da44c27dbccb1845387bc989eb76a3',1,'analizer.h']]],
  ['generatorpin',['GeneratorPin',['../analizer_8h.html#a1d0d1e6152ace91f351302a46b658fb8',1,'analizer.h']]]
];
