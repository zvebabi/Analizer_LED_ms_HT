var searchData=
[
  ['pulseend',['pulseEnd',['../analizer_8h.html#a81eef57f3f8c19b296ef1c12a59b66a8',1,'analizer.h']]]
];
