var searchData=
[
  ['writeconfigtouart',['writeConfigToUart',['../analizer_8cpp.html#a542beaf8dd30073f60ea105068373ec4',1,'writeConfigToUart():&#160;analizer.cpp'],['../analizer_8h.html#a542beaf8dd30073f60ea105068373ec4',1,'writeConfigToUart():&#160;analizer.cpp']]]
];
