var group__commands =
[
    [ "Main menu", "group__main__menu.html", "group__main__menu" ]
];