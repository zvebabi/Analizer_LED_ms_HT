var annotated =
[
    [ "current_t", "structcurrent__t.html", "structcurrent__t" ],
    [ "etalon_t", "structetalon__t.html", "structetalon__t" ]
];