var files =
[
    [ "Release", "dir_92709420fde8ca446636ff7c23065e8b.html", "dir_92709420fde8ca446636ff7c23065e8b" ],
    [ "analizer.cpp", "analizer_8cpp.html", "analizer_8cpp" ],
    [ "analizer.h", "analizer_8h.html", "analizer_8h" ]
];