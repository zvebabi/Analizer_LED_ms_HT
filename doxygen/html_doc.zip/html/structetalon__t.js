var structetalon__t =
[
    [ "g1", "structetalon__t.html#ab4214655b89793479404ebecceba1532", null ],
    [ "g2max", "structetalon__t.html#aa305307c0910629f044451f2ffcf8f5e", null ],
    [ "g2mid", "structetalon__t.html#ab1abc2cac2f88d6e47df1ded10ce0837", null ],
    [ "g2min", "structetalon__t.html#a1b997b8d360ed62c4b49d5d30e53f64b", null ],
    [ "k", "structetalon__t.html#a70cad7a56e0aaeb8998957d09cf99599", null ]
];